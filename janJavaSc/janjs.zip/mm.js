// const x = [2,30,10,-9,9.4,1,5]
// let t_m = 0
// let t_l = 0
// let t_e = 0
// for (let i = 0; i < x.length; i++){
//     if (x[i] > 10) {t_m+=1}
//     else if (x[i] < 10) {t_l+=1}
//     else {
//         t_e+=1
//     }
// }
// console.log(t_m);
// console.log(t_l);
// console.log(t_e);



// const x = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]
// let x_even = []
// for (let i = 0; i < x.length; i++){
//     if (x[i]%2 == 0) {x_even.push(x[i])}
    
// }
// console.log(x_even);

// const x = ['Hello', "world", 'cat']
// for (let i = 0; i < x.length; i++){
//     if (x[i].length >= 4){
//         console.log(x[i]);
//     }
// }


// let x = [2,30,10,-9,84,1,5]
// console.log(x);
// let x_rev = x.reverse()
// console.log(x_rev);
