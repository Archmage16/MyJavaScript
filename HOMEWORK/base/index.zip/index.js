// ПЕРВОЕ ЗАДАНИЕ
// var weight = prompt('Write your weight: ')
// var height = prompt('Write your height (in meters squared): ')

// var BMI = weight / (height ** 2)
// alert(BMI)




// ВТОРОЕ ЗАДАНИЕ
// const age = prompt('Write your age: ');

// if (0 <= age && age <= 12){
//     alert('You are a child');
// }else if (13<= age && age <= 17){
//     alert('You are a teenager');
// }else if (18 <= age && age <= 64){
//     alert('You are an adult!');
// }else if (age >= 65){
//     alert('You are an old person');
// }else{
//     alert('Wrong input!');
// }




// ТРЕТЬЕ ЗАДАНИЕ
// var a = prompt('Write a: ');
// var h = prompt('Write height: ');
// alert(`Triangle area = ${(a * h) / 2}`);




// ЧЕТВЕРТОЕ ЗАДАНИЕ
// var birthday = prompt('Введите вашу дату рождения (день пробел месяц): ');
// var list = birthday.split(' ');
// var month = Number(list[1]);
// var day = Number(list[0]);
// if ((month === 3 && day >= 21) || (month === 4 && day <= 19)) {
//     alert('Овен');
// } else if ((month === 4 && day >= 20) || (month === 5 && day <= 20)) {
//     alert('Телец');
// } else if ((month === 5 && day >= 21) || (month === 6 && day <= 20)) {
//     alert('Близнецы');
// } else if ((month === 6 && day >= 21) || (month === 7 && day <= 22)) {
//     alert('Рак');
// } else if ((month === 7 && day >= 23) || (month === 8 && day <= 22)) {
//     alert('Лев');
// } else if ((month === 8 && day >= 23) || (month === 9 && day <= 22)) {
//     alert('Дева');
// } else if ((month === 9 && day >= 23) || (month === 10 && day <= 22)) {
//     alert('Весы');
// } else if ((month === 10 && day >= 23) || (month === 11 && day <= 21)) {
//     alert('Скорпион');
// } else if ((month === 11 && day >= 22) || (month === 12 && day <= 21)) {
//     alert('Стрелец');
// } else if ((month === 12 && day >= 22) || (month === 1 && day <= 19)) {
//     alert('Козерог');
// } else if ((month === 1 && day >= 20) || (month === 2 && day <= 18)) {
//     alert('Водолей');
// } else if ((month === 2 && day >= 19) || (month === 3 && day <= 20)) {
//     alert('Рыбы');
// } else {
//     alert('Неверная дата');
// }




//ПЯТОЕ ЗАДАНИЕ
// var f = prompt('Write fahrenheit: ');
// var c = 5/9 * (f - 32)
// alert(`degrees Celsius = ${c}`);